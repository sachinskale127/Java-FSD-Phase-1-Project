package org.example;

import Functioanlity.Menu;

public class Main {

        public static final String path = "/Users/sackale/Downloads/Java_FSD_phase1";

        public static void main(String[] args) {
            Menu menu = new Menu();
            menu.introScreen();
            menu.mainMenu();
        }

}